package beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class QuestionAndAnswer {

	@Id  @GeneratedValue(strategy=GenerationType.AUTO) 
	private int id;
	String Question;
	String Answer;
	
	@ManyToMany
	List<PersonalDetails> patientDetail;

	public QuestionAndAnswer() {
		super();
	}

	public QuestionAndAnswer(int id, String question, String answer, List<PersonalDetails> patientDetail) {
		super();
		this.id = id;
		Question = question;
		Answer = answer;
		this.patientDetail = patientDetail;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getQuestion() {
		return Question;
	}

	public void setQuestion(String question) {
		Question = question;
	}

	public String getAnswer() {
		return Answer;
	}

	public void setAnswer(String answer) {
		Answer = answer;
	}

	public List<PersonalDetails> getPatientDetail() {
		return patientDetail;
	}

	public void setPatientDetail(List<PersonalDetails> patientDetail) {
		this.patientDetail = patientDetail;
	}
	
	
}

