package beans;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class PersonalDetails {
	@Id  @GeneratedValue(strategy=GenerationType.AUTO) 
	private int patientId;
	String fullName;
	String address;
	String email;
	Short phoneNumber;
	Short age;
	Date birthdate;
	String sex;
	
	@OneToOne
	HealthDetails healthDetails;
	
	@OneToMany
	List<Appointments> appointment;
	
	@ManyToMany
	List<QuestionAndAnswer> questionAndAnswer;
	
	public PersonalDetails() {
		super();
	}


	



	public PersonalDetails(int patientId, String fullName, String address, String email, Short phoneNumber, Short age,
			Date birthdate, String sex, HealthDetails healthDetails, List<Appointments> appointment,
			List<QuestionAndAnswer> questionAndAnswer) {
		super();
		this.patientId = patientId;
		this.fullName = fullName;
		this.address = address;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.age = age;
		this.birthdate = birthdate;
		this.sex = sex;
		this.healthDetails = healthDetails;
		this.appointment = appointment;
		this.questionAndAnswer = questionAndAnswer;
	}






	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Short getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(Short phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public Short getAge() {
		return age;
	}
	public void setAge(Short age) {
		this.age = age;
	}
	public Date getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(Date birthdate) {
		this.birthdate = birthdate;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}






	public HealthDetails getHealthDetails() {
		return healthDetails;
	}






	public void setHealthDetails(HealthDetails healthDetails) {
		this.healthDetails = healthDetails;
	}






	public List<Appointments> getAppointment() {
		return appointment;
	}






	public void setAppointment(List<Appointments> appointment) {
		this.appointment = appointment;
	}






	public List<QuestionAndAnswer> getQuestionAndAnswer() {
		return questionAndAnswer;
	}






	public void setQuestionAndAnswer(List<QuestionAndAnswer> questionAndAnswer) {
		this.questionAndAnswer = questionAndAnswer;
	}


	
	
	

}
