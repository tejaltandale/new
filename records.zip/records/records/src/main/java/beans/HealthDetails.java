package beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class HealthDetails {
	
	@Id  @GeneratedValue(strategy=GenerationType.AUTO) 
	private int id;
	String bloodType;
	int height;
	int weight;
	String disease;
	String preTreatmentDetails;
	
	@OneToOne
	PersonalDetails patientDetails;

	public HealthDetails() {
		super();
	}


	public HealthDetails(int id, String bloodType, int height, int weight, String disease, String preTreatmentDetails,
			PersonalDetails patientDetails) {
		super();
		this.id = id;
		this.bloodType = bloodType;
		this.height = height;
		this.weight = weight;
		this.disease = disease;
		this.preTreatmentDetails = preTreatmentDetails;
		this.patientDetails = patientDetails;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public String getDisease() {
		return disease;
	}

	public void setDisease(String disease) {
		this.disease = disease;
	}

	public String getPreTreatmentDetails() {
		return preTreatmentDetails;
	}

	public void setPreTreatmentDetails(String preTreatmentDetails) {
		this.preTreatmentDetails = preTreatmentDetails;
	}

	public PersonalDetails getPatientDetails() {
		return patientDetails;
	}

	public void setPatientDetails(PersonalDetails patientDetails) {
		this.patientDetails = patientDetails;
	}


	public String getBloodType() {
		return bloodType;
	}


	public void setBloodType(String bloodType) {
		this.bloodType = bloodType;
	}

	
}
