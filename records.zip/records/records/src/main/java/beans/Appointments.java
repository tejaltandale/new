package beans;

import java.util.Date;
import java.util.Timer;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Appointments {

	@Id  @GeneratedValue(strategy=GenerationType.AUTO) 
	private int id;
	String fullName;
	String reason;
	Date appointmentDate;
	Timer appointmentTime;
	
	@ManyToOne
	PersonalDetails patientDetails;

	public Appointments() {
		super();
	}

	public Appointments(int id, String fullName, String reason, Date appointmentDate, Timer appointmentTime,
			PersonalDetails patientDetails) {
		super();
		this.id = id;
		this.fullName = fullName;
		this.reason = reason;
		this.appointmentDate = appointmentDate;
		this.appointmentTime = appointmentTime;
		this.patientDetails = patientDetails;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Date getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public Timer getAppointmentTime() {
		return appointmentTime;
	}

	public void setAppointmentTime(Timer appointmentTime) {
		this.appointmentTime = appointmentTime;
	}

	public PersonalDetails getPatientDetails() {
		return patientDetails;
	}

	public void setPatientDetails(PersonalDetails patientDetails) {
		this.patientDetails = patientDetails;
	}
	
	
}
