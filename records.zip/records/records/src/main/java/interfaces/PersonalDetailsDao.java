package interfaces;

import java.util.List;


import beans.PersonalDetails;

public interface PersonalDetailsDao {
	public PersonalDetails save(PersonalDetails personamDetails);
	
	public List<PersonalDetails> searchByName(String title);
	public List<PersonalDetails> searchById(int id);
	public List<PersonalDetails> searchByDisease(String disease);
	public Boolean modifyDetails(int id,PersonalDetails personamDetails);
	

}
