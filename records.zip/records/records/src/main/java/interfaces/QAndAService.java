package interfaces;

import java.util.HashMap;
import java.util.List;

import beans.QuestionAndAnswer;

public interface QAndAService {
	
public QuestionAndAnswer add(HashMap map);
	
	public List<QuestionAndAnswer> searchByName(String name);
	public List<QuestionAndAnswer> searchByDisease(String disease);
	

}
