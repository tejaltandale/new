package interfaces;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import beans.Appointments;

public interface AppointmentService {

public Appointments addData(HashMap map);
	
	public List<Appointments> searchByDate(Date date);
	public List<Appointments> searchByDisease(String disease);
	public Boolean modifyDetails(HashMap map);
}
