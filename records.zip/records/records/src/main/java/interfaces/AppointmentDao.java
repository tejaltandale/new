package interfaces;

import java.util.Date;
import java.util.List;

import beans.Appointments;



public interface AppointmentDao {

	public Appointments save(Appointments Appointments);
	
	public List<Appointments> searchByDate(Date date);
	public List<Appointments> searchByDisease(String disease);
	public Boolean modifyDetails(int id,Appointments Appointments);

}
