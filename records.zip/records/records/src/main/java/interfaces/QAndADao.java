package interfaces;

import java.util.Date;
import java.util.List;

import beans.QuestionAndAnswer;



public interface QAndADao {
	
public QuestionAndAnswer save(QuestionAndAnswer QuestionAndAnswer);
	
	public List<QuestionAndAnswer> searchByName(String name);
	public List<QuestionAndAnswer> searchByDisease(String disease);
	

}
