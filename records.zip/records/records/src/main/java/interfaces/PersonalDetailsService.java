package interfaces;

import java.util.HashMap;
import java.util.List;

import beans.PersonalDetails;



public interface PersonalDetailsService {

	public String addPersonalDetails(HashMap map);
	public List<PersonalDetails> searchByName(String title);
	public List<PersonalDetails> searchById(int id);
	public List<PersonalDetails> searchByDisease(String disease);
	public Boolean modifyDetails(HashMap map);
}
