package implementation;

import java.util.Date;
import java.util.HashMap;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import interfaces.PersonalDetailsService;

public class UserInterface {

	protected static EntityManager em;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		EntityManager em = emf.createEntityManager();
		PersonalDetailsServiceImpl personalDetails=new PersonalDetailsServiceImpl(em);
		em.getTransaction().begin();
		
		HashMap<String, String> healthDetail = new HashMap<String, String>();
		healthDetail.put("Blood Type", "A+");
		healthDetail.put("Weight", "50");
		healthDetail.put("Height", "160");
		healthDetail.put("disease", "fever");
		healthDetail.put("Pretreatment", "NO");
		
		HashMap<String, Object> personalDetail = new HashMap<String, Object>();
		personalDetail.put("Name", "Tejal Sanjay Tandale");
		personalDetail.put("Address", "Pune");
		personalDetail.put("Email", "tandaletejal@gmail.com");
		personalDetail.put("Phone Number", "776830696");
		personalDetail.put("DOB", new Date());
		personalDetail.put("Sex", "Female");
		personalDetail.put("Health Details",healthDetail);
		 
		personalDetails.addPersonalDetails(personalDetail);
		
		em.getTransaction().commit();
		em.close();
		emf.close();
	}

}
