package implementation;

import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;

import beans.HealthDetails;
import beans.PersonalDetails;
import interfaces.PersonalDetailsDao;
import interfaces.PersonalDetailsService;

public class PersonalDetailsServiceImpl implements PersonalDetailsService {
	
	private PersonalDetailsDao personalDetailsDao;
	private HealthDetails healthDetails;
	
	

	public PersonalDetailsServiceImpl(PersonalDetailsDao personalDetailsDao) {
		super();
		this.personalDetailsDao = personalDetailsDao;
	}

	public PersonalDetailsServiceImpl(EntityManager em) {
		// TODO Auto-generated constructor stub
		personalDetailsDao=new PersonalDetailsDaoImpl(em);
	}

	public String addPersonalDetails(HashMap map) {
		// TODO Auto-generated method stub
		if (map == null) {
			throw new NullPointerException();

		} else {
			
		
		}
		return null;
	}

	public List<PersonalDetails> searchByName(String title) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<PersonalDetails> searchById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<PersonalDetails> searchByDisease(String disease) {
		// TODO Auto-generated method stub
		return null;
	}

	public Boolean modifyDetails(HashMap map) {
		// TODO Auto-generated method stub
		return null;
	}

}
