package implementation;

import java.util.List;

import javax.persistence.EntityManager;

import beans.PersonalDetails;
import interfaces.PersonalDetailsDao;



public class PersonalDetailsDaoImpl implements PersonalDetailsDao {
	private EntityManager em;

	public PersonalDetailsDaoImpl(EntityManager em) {
		this.em = em;
	}

	public PersonalDetails save(PersonalDetails PersonalDetails) {
		try {
			em.persist(PersonalDetails);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return PersonalDetails;
	}

	public List<PersonalDetails> searchByName(String title) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<PersonalDetails> searchById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<PersonalDetails> searchByDisease(String disease) {
		// TODO Auto-generated method stub
		return null;
	}

	public Boolean modifyDetails(int id, PersonalDetails personamDetails) {
		// TODO Auto-generated method stub
		return null;
	}
}
